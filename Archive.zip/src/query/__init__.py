"""Query processing module for WekaDocs GraphRAG MCP."""
