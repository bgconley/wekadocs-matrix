"""Cypher query templates for common intents."""
