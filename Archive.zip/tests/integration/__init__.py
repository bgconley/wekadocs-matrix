"""Integration tests for wekadocs-matrix."""
