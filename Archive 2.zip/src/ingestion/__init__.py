from .api import ingest_document

__all__ = ["ingest_document"]
