#!/usr/bin/env python3
"""
Database Cleanup Script - Surgical Data Deletion with Schema Preservation

This script performs surgical cleanup of all test/development data from:
- Neo4j (nodes + relationships, preserves constraints + indexes)
- Qdrant (vectors, preserves collection schemas)
- Redis (keys in specified database)

Generates comprehensive before/after reports with schema verification.

Usage:
    python scripts/cleanup-databases.py [options]

Options:
    --dry-run           Show what would be deleted without actually deleting
    --redis-db N        Redis database number to clean (default: 1)
    --skip-neo4j        Skip Neo4j cleanup
    --skip-qdrant       Skip Qdrant cleanup
    --skip-redis        Skip Redis cleanup
    --report-dir PATH   Custom report directory (default: reports/cleanup/)
    --quiet             Minimal console output
    --help              Show this help message

Examples:
    # Standard cleanup with full reporting
    python scripts/cleanup-databases.py

    # Dry run to preview changes
    python scripts/cleanup-databases.py --dry-run

    # Clean only Neo4j
    python scripts/cleanup-databases.py --skip-qdrant --skip-redis

    # Clean production Redis db (use with caution!)
    python scripts/cleanup-databases.py --redis-db 0 --skip-neo4j --skip-qdrant

Safety:
    - NEVER deletes Neo4j constraints or indexes
    - NEVER deletes Qdrant collection schemas (recreates empty)
    - ONLY deletes data in specified Redis database
    - Generates full audit trail in reports/

Author: Claude Code
Generated: 2025-10-18
"""

import argparse
import json
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict

# Add src to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

try:
    import redis
    from neo4j import GraphDatabase
    from qdrant_client import QdrantClient

    from shared.config import init_config
except ImportError as e:
    print(f"❌ Import error: {e}")
    print("   Make sure you're running from the project root:")
    print("   python scripts/cleanup-databases.py")
    sys.exit(1)


class DatabaseCleaner:
    """Handles surgical cleanup of all databases with comprehensive reporting."""

    def __init__(self, args: argparse.Namespace):
        self.args = args
        self.config = None
        self.settings = None
        self.report_data = {
            "timestamp": datetime.now().isoformat(),
            "dry_run": args.dry_run,
            "options": vars(args),
            "before": {},
            "after": {},
            "actions": [],
            "errors": [],
            "summary": {},
        }

        # Initialize config
        try:
            self.config, self.settings = init_config()
        except Exception as e:
            self._log_error(f"Failed to load config: {e}")
            sys.exit(1)

    def _log(self, message: str, level: str = "info"):
        """Log message to console and report."""
        if not self.args.quiet or level == "error":
            prefix = {
                "info": "  ",
                "success": "✅",
                "warning": "⚠️ ",
                "error": "❌",
                "header": "",
            }.get(level, "  ")
            print(f"{prefix} {message}")

    def _log_error(self, message: str):
        """Log error message."""
        self._log(message, "error")
        self.report_data["errors"].append(
            {"timestamp": datetime.now().isoformat(), "message": message}
        )

    def _log_action(self, action: str, details: Dict[str, Any]):
        """Log an action taken."""
        self.report_data["actions"].append(
            {
                "timestamp": datetime.now().isoformat(),
                "action": action,
                "details": details,
            }
        )

    def cleanup_neo4j(self) -> bool:
        """
        Clean Neo4j database - delete all data, preserve schema.

        Returns:
            bool: True if successful, False otherwise
        """
        if self.args.skip_neo4j:
            self._log("Skipping Neo4j cleanup (--skip-neo4j)", "warning")
            return True

        self._log("Neo4j Data Cleanup", "header")
        self._log("-" * 60, "header")

        try:
            driver = GraphDatabase.driver(
                self.settings.neo4j_uri,
                auth=(self.settings.neo4j_user, self.settings.neo4j_password),
            )

            with driver.session() as session:
                # Capture before state
                before_nodes = session.run(
                    "MATCH (n) RETURN count(n) as count"
                ).single()["count"]
                before_rels = session.run(
                    "MATCH ()-[r]->() RETURN count(r) as count"
                ).single()["count"]
                constraints = list(session.run("SHOW CONSTRAINTS"))
                indexes = list(session.run("SHOW INDEXES"))

                before_state = {
                    "nodes": before_nodes,
                    "relationships": before_rels,
                    "constraints": len(constraints),
                    "indexes": len(indexes),
                }
                self.report_data["before"]["neo4j"] = before_state

                self._log(f"Before: {before_nodes} nodes, {before_rels} relationships")
                self._log(
                    f"Schema: {len(constraints)} constraints, "
                    f"{len(indexes)} indexes"
                )

                # Delete data (unless dry run)
                if not self.args.dry_run:
                    session.run("MATCH (n) DETACH DELETE n")
                    self._log_action(
                        "neo4j_delete_all",
                        {"nodes_deleted": before_nodes, "rels_deleted": before_rels},
                    )
                    self._log("Data deleted", "success")
                else:
                    self._log(
                        "DRY RUN: Would delete all nodes/relationships", "warning"
                    )

                # Capture after state
                after_nodes = session.run(
                    "MATCH (n) RETURN count(n) as count"
                ).single()["count"]
                after_rels = session.run(
                    "MATCH ()-[r]->() RETURN count(r) as count"
                ).single()["count"]
                after_constraints = list(session.run("SHOW CONSTRAINTS"))
                after_indexes = list(session.run("SHOW INDEXES"))

                after_state = {
                    "nodes": after_nodes,
                    "relationships": after_rels,
                    "constraints": len(after_constraints),
                    "indexes": len(after_indexes),
                }
                self.report_data["after"]["neo4j"] = after_state

                self._log(f"After: {after_nodes} nodes, {after_rels} relationships")

                # Verify schema preservation
                if len(after_constraints) == len(constraints):
                    self._log(
                        f"Schema preserved: {len(constraints)} constraints, "
                        f"{len(indexes)} indexes",
                        "success",
                    )
                else:
                    self._log(
                        f"Schema changed! "
                        f"Before: {len(constraints)}c/{len(indexes)}i, "
                        f"After: {len(after_constraints)}c/{len(after_indexes)}i",
                        "error",
                    )
                    return False

            driver.close()
            return True

        except Exception as e:
            self._log_error(f"Neo4j cleanup failed: {e}")
            return False

    def cleanup_qdrant(self) -> bool:
        """
        Clean Qdrant database - delete all vectors, preserve collection schemas.

        Returns:
            bool: True if successful, False otherwise
        """
        if self.args.skip_qdrant:
            self._log("Skipping Qdrant cleanup (--skip-qdrant)", "warning")
            return True

        self._log("", "header")
        self._log("Qdrant Vector Cleanup", "header")
        self._log("-" * 60, "header")

        try:
            qdrant = QdrantClient(
                host=self.settings.qdrant_host, port=self.settings.qdrant_port
            )

            collections = qdrant.get_collections().collections
            qdrant_before = {}
            qdrant_after = {}

            for coll in collections:
                coll_info = qdrant.get_collection(coll.name)
                before_count = coll_info.points_count

                qdrant_before[coll.name] = {
                    "vector_count": before_count,
                    "config": str(coll_info.config.params.vectors)[:100],
                }

                self._log(f"Collection: {coll.name}")
                self._log(f"Before: {before_count} vectors")

                # Delete collection (unless dry run)
                if not self.args.dry_run:
                    qdrant.delete_collection(coll.name)
                    self._log_action(
                        "qdrant_delete_collection",
                        {"collection": coll.name, "vectors_deleted": before_count},
                    )
                    self._log(f"Deleted {before_count} vectors", "success")
                    qdrant_after[coll.name] = {"vector_count": 0, "deleted": True}
                else:
                    self._log(
                        f"DRY RUN: Would delete collection with {before_count} vectors",
                        "warning",
                    )
                    qdrant_after[coll.name] = qdrant_before[coll.name]

            self.report_data["before"]["qdrant"] = qdrant_before
            self.report_data["after"]["qdrant"] = qdrant_after

            return True

        except Exception as e:
            self._log_error(f"Qdrant cleanup failed: {e}")
            return False

    def cleanup_redis(self) -> bool:
        """
        Clean Redis database - delete all keys in specified database.

        Returns:
            bool: True if successful, False otherwise
        """
        if self.args.skip_redis:
            self._log("Skipping Redis cleanup (--skip-redis)", "warning")
            return True

        self._log("", "header")
        self._log("Redis Test Database Cleanup", "header")
        self._log("-" * 60, "header")

        try:
            redis_password = os.getenv("REDIS_PASSWORD", "")
            redis_uri = (
                f"redis://:{redis_password}@localhost:6379/{self.args.redis_db}"
                if redis_password
                else f"redis://localhost:6379/{self.args.redis_db}"
            )

            r = redis.Redis.from_url(redis_uri, decode_responses=True)

            # Capture before state
            before_keys = r.keys("*")
            before_count = len(before_keys)

            redis_before = {
                "db": self.args.redis_db,
                "key_count": before_count,
                "sample_keys": before_keys[:10] if before_keys else [],
            }
            self.report_data["before"]["redis"] = redis_before

            self._log(f"Database: db={self.args.redis_db}")
            self._log(f"Before: {before_count} keys")

            # Delete keys (unless dry run)
            if not self.args.dry_run:
                r.flushdb()
                self._log_action(
                    "redis_flushdb",
                    {"db": self.args.redis_db, "keys_deleted": before_count},
                )
                self._log(f"Deleted {before_count} keys", "success")
            else:
                self._log(f"DRY RUN: Would delete {before_count} keys", "warning")

            # Capture after state
            after_keys = r.keys("*") if not self.args.dry_run else before_keys
            after_count = len(after_keys)

            redis_after = {"db": self.args.redis_db, "key_count": after_count}
            self.report_data["after"]["redis"] = redis_after

            self._log(f"After: {after_count} keys")

            return True

        except Exception as e:
            self._log_error(f"Redis cleanup failed: {e}")
            return False

    def generate_report(self) -> Path:
        """
        Generate comprehensive cleanup report.

        Returns:
            Path: Path to generated report file
        """
        # Create report directory
        report_dir = Path(self.args.report_dir)
        report_dir.mkdir(parents=True, exist_ok=True)

        # Generate report filename
        timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        report_file = report_dir / f"cleanup-report-{timestamp}.json"

        # Calculate summary statistics
        summary = {
            "dry_run": self.args.dry_run,
            "success": len(self.report_data["errors"]) == 0,
            "databases_cleaned": [],
        }

        if not self.args.skip_neo4j:
            neo4j_before = self.report_data["before"].get("neo4j", {})
            neo4j_after = self.report_data["after"].get("neo4j", {})
            summary["databases_cleaned"].append(
                {
                    "database": "neo4j",
                    "nodes_deleted": neo4j_before.get("nodes", 0)
                    - neo4j_after.get("nodes", 0),
                    "relationships_deleted": neo4j_before.get("relationships", 0)
                    - neo4j_after.get("relationships", 0),
                    "schema_preserved": (
                        neo4j_before.get("constraints")
                        == neo4j_after.get("constraints")
                        and neo4j_before.get("indexes") == neo4j_after.get("indexes")
                    ),
                }
            )

        if not self.args.skip_qdrant:
            qdrant_before = self.report_data["before"].get("qdrant", {})
            total_vectors = sum(
                coll.get("vector_count", 0) for coll in qdrant_before.values()
            )
            summary["databases_cleaned"].append(
                {
                    "database": "qdrant",
                    "collections_deleted": len(qdrant_before),
                    "total_vectors_deleted": total_vectors,
                }
            )

        if not self.args.skip_redis:
            redis_before = self.report_data["before"].get("redis", {})
            redis_after = self.report_data["after"].get("redis", {})
            summary["databases_cleaned"].append(
                {
                    "database": "redis",
                    "db": self.args.redis_db,
                    "keys_deleted": redis_before.get("key_count", 0)
                    - redis_after.get("key_count", 0),
                }
            )

        self.report_data["summary"] = summary

        # Write report
        with open(report_file, "w") as f:
            json.dump(self.report_data, f, indent=2)

        return report_file

    def run(self) -> int:
        """
        Execute cleanup workflow.

        Returns:
            int: Exit code (0 = success, 1 = failure)
        """
        self._log("=" * 60, "header")
        mode = "DRY RUN - " if self.args.dry_run else ""
        self._log(f"{mode}DATABASE CLEANUP - SURGICAL DATA DELETION", "header")
        self._log("=" * 60, "header")
        self._log(f"Timestamp: {self.report_data['timestamp']}", "header")
        self._log("", "header")

        # Execute cleanup steps
        success = True
        success &= self.cleanup_neo4j()
        success &= self.cleanup_qdrant()
        success &= self.cleanup_redis()

        # Generate report
        self._log("", "header")
        self._log("=" * 60, "header")
        self._log("CLEANUP COMPLETE" if success else "CLEANUP FAILED", "header")
        self._log("=" * 60, "header")

        try:
            report_file = self.generate_report()
            self._log(f"Report saved: {report_file}", "success")
        except Exception as e:
            self._log_error(f"Failed to generate report: {e}")
            success = False

        # Print summary
        if success:
            if self.args.dry_run:
                self._log("DRY RUN completed - no changes made", "warning")
            else:
                self._log("All data deleted successfully", "success")
                self._log("All schemas preserved", "success")
                self._log("System ready for fresh test run", "success")
        else:
            self._log(f"{len(self.report_data['errors'])} error(s) occurred", "error")

        self._log("", "header")

        return 0 if success else 1


def parse_args():
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(
        description="Surgical database cleanup with schema preservation",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )

    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be deleted without actually deleting",
    )
    parser.add_argument(
        "--redis-db",
        type=int,
        default=1,
        help="Redis database number to clean (default: 1 = test db)",
    )
    parser.add_argument("--skip-neo4j", action="store_true", help="Skip Neo4j cleanup")
    parser.add_argument(
        "--skip-qdrant", action="store_true", help="Skip Qdrant cleanup"
    )
    parser.add_argument("--skip-redis", action="store_true", help="Skip Redis cleanup")
    parser.add_argument(
        "--report-dir",
        type=str,
        default="reports/cleanup",
        help="Custom report directory (default: reports/cleanup/)",
    )
    parser.add_argument("--quiet", action="store_true", help="Minimal console output")

    return parser.parse_args()


def main():
    """Main entry point."""
    args = parse_args()

    # Validate args
    if args.skip_neo4j and args.skip_qdrant and args.skip_redis:
        print("❌ Error: Cannot skip all databases. Nothing to clean!")
        return 1

    # Run cleanup
    cleaner = DatabaseCleaner(args)
    return cleaner.run()


if __name__ == "__main__":
    sys.exit(main())
